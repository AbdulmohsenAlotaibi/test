/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.sql.ResultSet;
import java.util.Queue;
import querybuilders.DBTransaction;
import querybuilders.QueryBuilder;
import querybuilders.SelectQueryBuilder;

/**
 *
 * @author AboDy
 */
public abstract class Model {
    
    
    protected Model()
    {
        
    }
    
    protected abstract void delete();
    protected abstract void create();
    protected abstract void update();
    
}
