/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.sql.ResultSet;
import java.util.Queue;
import querybuilders.DBTransaction;
import querybuilders.SelectQueryBuilder;

/**
 *
 * @author AboDy
 */
public class Profile extends Model {
    
    public static Profile find(int id)
    {
        
        return new Profile();
    }
    
    public static Profile where(String column, String operator, Object value)
    {
        SelectQueryBuilder builder = new SelectQueryBuilder(User.class).select("name", "age").andWhere(column, operator, value);
        DBTransaction transaction = DBTransaction.execute(builder);
        ResultSet result = transaction.getResultSet();
        // manage the results
        
        // close 
        transaction.close();
        
        // return the new user
        return new Profile();
    }

    @Override
    protected void delete() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void create() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void update() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
