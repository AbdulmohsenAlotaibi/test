/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.sql.ResultSet;
import java.util.Queue;
import querybuilders.DBTransaction;
import querybuilders.InsertQueryBuilder;
import querybuilders.SelectQueryBuilder;
import querybuilders.UpdateQueryBuilder;

/**
 *
 * @author AboDy
 */
public class User extends Model {
    
    private String name;
    private int age;
    
    public User()
    {
    }
    
    // if we wanted to create a new user to insert it to db
    public User(String name, int age)
    {
        this.name = name;
        this.age = age;
    }
    
    public static User find(int id)
    {
        SelectQueryBuilder builder = new SelectQueryBuilder(User.class).select("name", "age").andWhere("age", "<", 45);
        DBTransaction transaction = DBTransaction.execute(builder);
        ResultSet result = transaction.getResultSet();
        // manage the results
        
        // close 
        transaction.close();
        
        // return the new user
        return new User();
    }
    
    public static User where(String column, String operator, Object value)
    {
        SelectQueryBuilder builder = new SelectQueryBuilder(User.class).select("name", "age").andWhere(column, operator, value);
        DBTransaction transaction = DBTransaction.execute(builder);
        ResultSet result = transaction.getResultSet();
        // manage the results
        
        // close 
        transaction.close();
        
        // return the new user
        return new User();
    }

    @Override
    public void delete() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void create() {
        
        InsertQueryBuilder builder = new InsertQueryBuilder(User.class).value("name", "hello").value("age", 45);
        DBTransaction transaction = DBTransaction.execute(builder);
        ResultSet result = transaction.getResultSet();
        // manage the results
        
        // close 
        transaction.close();
    }
    
    @Override
    public void update() {
        
        UpdateQueryBuilder builder = new UpdateQueryBuilder(User.class).value("name", "hello").value("age", 45).andWhere("name", "=", "abdul").orWhere("age", "<", 20);
        DBTransaction transaction = DBTransaction.execute(builder);
        ResultSet result = transaction.getResultSet();
        // manage the results
        
        // close 
        transaction.close();
        
    }
    
}
