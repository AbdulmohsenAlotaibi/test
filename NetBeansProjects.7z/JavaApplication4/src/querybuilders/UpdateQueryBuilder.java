/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package querybuilders;

import java.util.ArrayDeque;
import java.util.PriorityQueue;
import java.util.Queue;

/**
 *
 * @author AboDy
 */
public class UpdateQueryBuilder extends QueryBuilder {
    
    private String update_columns = "";
    private Queue<Object> update_parameters;
    
    public UpdateQueryBuilder(Class<?> table)
    {
        super(table);
        update_parameters = new ArrayDeque<>();
    }
    
    // where function
    @Override
    public UpdateQueryBuilder andWhere(String column, String operator , Object value)
    {
        super.andWhere(column, operator, value);
        return this;
    }
    
    // where function
    @Override
    public UpdateQueryBuilder orWhere(String column, String operator , Object value)
    {
        super.orWhere(column, operator, value);
        return this;
    }
    
    public UpdateQueryBuilder value(String column , Object value)
    {
        // if no columns were added before then no need for a comma
        if(update_columns.length() == 0)
        {
            update_columns = column + "=?";
        }
        else
        {
            update_columns += "," + column + "=?";
        }
        // insert the parameter
        update_parameters.add(value);
        return this;
    }
    
    // returns the full query
    @Override
    public String getQuery()
    {
        return "UPDATE " + table + " SET " + update_columns + " " + where;
    }

    @Override
    public Queue<Object> getParameters() {
        // merge all queues in order
        Queue<Object> parameters = new ArrayDeque<>();
        // add all update parameters
        for(Object obj : update_parameters)
            parameters.add(obj);
        // add all where parameters
        for(Object obj : where_parameters)
            parameters.add(obj);
        return parameters;
    }
    
}
