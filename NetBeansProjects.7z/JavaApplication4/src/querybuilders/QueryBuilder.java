/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package querybuilders;

import java.util.ArrayDeque;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;

/**
 *
 * @author AboDy
 */
public abstract class QueryBuilder {
    
    protected String table;
    protected Queue<Object> where_parameters;
    protected String where = "";
    
    protected QueryBuilder(Class<?> table)
    {
        this.table = table.getSimpleName().toLowerCase();
        where_parameters = new ArrayDeque<>();
    }
    
    // where function
    public QueryBuilder andWhere(String column, String operator , Object value)
    {
        String new_cond = column + operator + "?";
        // if no condition is inserted before then insert without logical operator
        if(where.length() == 0)
        {
            where = "WHERE " + new_cond;
        }
        else
        {
            where += " AND " + new_cond;
        }
        // insert the parameter
        where_parameters.add(value);
        return this;
    }
    
    // where function
    public QueryBuilder orWhere(String column, String operator , Object value)
    {
        String new_cond = column + operator + "?";
        // if no condition is inserted before then insert without logical operator
        if(where.length() == 0)
        {
            where = "WHERE " + new_cond;
        }
        else
        {
            where += " OR " + new_cond;
        }
        // insert the parameter
        where_parameters.add(value);
        return this;
    }
    
    public abstract String getQuery();
    
    public abstract Queue<Object> getParameters();
    
    
}
