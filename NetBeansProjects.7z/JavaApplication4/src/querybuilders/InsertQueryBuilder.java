/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package querybuilders;

import java.util.ArrayDeque;
import java.util.PriorityQueue;
import java.util.Queue;

/**
 *
 * @author AboDy
 */
public class InsertQueryBuilder extends QueryBuilder {
    
    // attributes to handle this query
    private String project_columns = "";
    private String values_to_insert = "";
    private Queue<Object> insert_parameters;
    
    public InsertQueryBuilder(Class<?> table)
    {
        super(table);
        insert_parameters = new ArrayDeque<>();
    }
    
    // select function
    public InsertQueryBuilder columns(String ... columns)
    {
        for(int i = 0; i < columns.length; i++)
        {
            String col = columns[i];
            // insert the column into the query, add a comma if columns were slected before
            project_columns += (project_columns.length() == 0 ? col : "," + col);
        }
        return this;
    }
    
    // where function
    public InsertQueryBuilder value(String column , Object value)
    {
        // if no columns were added before then no need for a comma
        if(project_columns.length() == 0)
        {
            project_columns = column;
            values_to_insert = "?";
        }
        else
        {
            project_columns += "," + column;
            values_to_insert += ",?";
        }
        // insert the parameter
        insert_parameters.add(value);
        return this;
    }
    
    // returns the full query
    @Override
    public String getQuery()
    {
        return "INSERT INTO " + table + "(" + project_columns + ") VALUES(" + values_to_insert + ")";
    }

    @Override
    public Queue<Object> getParameters() {
        return insert_parameters;
    }
    
}
