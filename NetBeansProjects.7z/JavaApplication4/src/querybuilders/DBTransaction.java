/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package querybuilders;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Queue;

/**
 *
 * @author AboDy
 */
public class DBTransaction {
    
    private Connection connection;
    private PreparedStatement stmt;
    private ResultSet result;
    
    private DBTransaction(String query, Queue<Object> parameters)
    {
        try
        {
            connection = DriverManager.getConnection("");
            stmt = connection.prepareStatement(query);
            
            for(int i = 0; i < parameters.size(); i++)
                stmt.setObject(i, parameters.poll());
            result = stmt.executeQuery();
        }catch(SQLException e)
        {
            
        }
    }
    
    public static DBTransaction execute(QueryBuilder builder)
    {
        String query = builder.getQuery();
        Queue<Object> parameters = builder.getParameters();
        System.out.println(query + " -> objects: " + parameters.toString());
        DBTransaction transaction = new DBTransaction(query, parameters);
        return transaction;
    }
    
    public ResultSet getResultSet()
    {
        return result;
    }
    
    // called when the object is about to finalize
    @Override
    public void finalize() throws Throwable
    {
        close();
        super.finalize();
    }
    
    // called just in case
    public void close()
    {
        try
        {
            if(result != null)
                result.close();
            if(stmt != null)
                stmt.close();
            if(connection != null)
                connection.close();
        }catch(SQLException e)
        {
            
        }
    }
    
    
}
