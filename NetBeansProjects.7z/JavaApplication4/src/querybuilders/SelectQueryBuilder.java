/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package querybuilders;

import java.util.PriorityQueue;
import java.util.Queue;

/**
 *
 * @author AboDy
 */
public class SelectQueryBuilder extends QueryBuilder {
    
    // attributes to handle this query
    private String distinct_col = "";
    private String project_columns = "";
    private String groupByVal = "";
    private String orderByVal = "";
    
    public SelectQueryBuilder(Class<?> table)
    {
        super(table);
    }
    
    // selects distinct column
    public SelectQueryBuilder distinct(String column)
    {
        distinct_col = "DISTINCT " + column;
        return this;
    }
    
    // select function
    public SelectQueryBuilder select(String ... columns)
    {
        for(int i = 0; i < columns.length; i++)
        {
            String col = columns[i];
            // insert the column into the query, add a comma if columns were slected before
            project_columns += (project_columns.length() == 0 ? col : "," + col);
        }
        return this;
    }
    
    // where function
    @Override
    public SelectQueryBuilder andWhere(String column, String operator , Object value)
    {
        super.andWhere(column, operator, value);
        return this;
    }
    
    // where function
    @Override
    public SelectQueryBuilder orWhere(String column, String operator , Object value)
    {
        super.orWhere(column, operator, value);
        return this;
    }
    
    // group by function
    public SelectQueryBuilder groupBy(String column)
    {
        // if group by was added before then add the new column with comma
        if(groupByVal.length() == 0)
        {
            groupByVal = "GROUP BY " + column;
        }
        else
        {
            groupByVal += "," + column;
        }
        return this;
    }
    
    // order by function
    public SelectQueryBuilder orderBy(String column, String type)
    {
        // if order by was added before then add the new column with comma
        if(orderByVal.length() == 0)
        {
            orderByVal = "ORDER BY " + column + " " + type;
        }
        else
        {
            orderByVal += "," + column + " " + type;
        }
        return this;
    }
    
    // returns the full query
    @Override
    public String getQuery()
    {
        // if we have a distinct column then add a comma to avoid error in query (unless we did not select any columns after), else no need
        String what_to_select = distinct_col;
        if(what_to_select.length() > 0 && project_columns.length() > 0)
            what_to_select += ",";
        // add the remaining columns
        what_to_select += project_columns;
        return "SELECT " + what_to_select + " FROM " + table + " " + where + " " + groupByVal + " " + orderByVal;
    }

    @Override
    public Queue<Object> getParameters() {
        return where_parameters;
    }
    
}
