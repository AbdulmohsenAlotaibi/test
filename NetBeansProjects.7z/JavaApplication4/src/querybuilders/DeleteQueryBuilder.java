/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package querybuilders;

import java.util.PriorityQueue;
import java.util.Queue;

/**
 *
 * @author AboDy
 */
public class DeleteQueryBuilder extends QueryBuilder {
    
    
    public DeleteQueryBuilder(Class<?> table)
    {
        super(table);
    }
    
    // where function
    @Override
    public DeleteQueryBuilder andWhere(String column, String operator , Object value)
    {
        super.andWhere(column, operator, value);
        return this;
    }
    
    // where function
    @Override
    public DeleteQueryBuilder orWhere(String column, String operator , Object value)
    {
        super.orWhere(column, operator, value);
        return this;
    }
    
    // returns the full query
    @Override
    public String getQuery()
    {
        return "DELETE FROM " + table + " " + where;
    }

    @Override
    public Queue<Object> getParameters() {
        return where_parameters;
    }
    
}
