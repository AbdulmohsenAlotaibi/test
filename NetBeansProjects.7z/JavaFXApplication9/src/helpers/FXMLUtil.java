/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helpers;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

/**
 *
 * @author AboDy
 */
public abstract class FXMLUtil {

    public static Scene loadScene(String location) throws IOException
    {
        return new Scene(loadParent(location));
    }
    
    public static Parent loadParent(String location) throws IOException
    {
        return FXMLLoader.load(FXMLUtil.class.getResource(location));
    }
    
}
